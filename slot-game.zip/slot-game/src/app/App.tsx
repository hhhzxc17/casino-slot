import { MainPage } from "../pages/main-page";

function App() {
  return (
    <div>
      <MainPage />
    </div>
  );
}

export default App;
