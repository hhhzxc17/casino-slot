export { default as MainPage } from "./ui/MainPage";
